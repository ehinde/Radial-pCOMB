%First lets threshold the anisotropy values
Total_AnisotropyM(Total_AnisotropyM<0.1)=0;
A=Total_AnisotropyM;
A(A==NaN)=0;
A([1:6],[1:64])=0;
A([59:64],[1:64])=0;
A([1:64],[1:6])=0;
A([1:64],[59:64])=0;
%L is the length 
%Angle is theta

Total_AngleM(Total_AngleM==0)= NaN;
for i=1:64
    for j=1:64
        L=2*A(i,j);
        Theta=Total_AngleM(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','R','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 65])
  xlim([0 65])
  set(gcf,'color','w')
end 
%%
%First lets threshold the anisotropy values
Total_AnisotropyM(Total_AnisotropyM<0.1)=0;
A=Total_AnisotropyM;
A([1:8],[1:64])=0;
A([57:64],[1:64])=0;
A([1:64],[1:8])=0;
A([1:64],[57:64])=0;
%L is the length 
%Angle is theta
%Total_AngleM(Total_AngleM<0)= NaN;
for i=1:64
    for j=1:64
        L=2*A(i,j);
        Theta=Total_AngleM(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','R','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 65])
  xlim([0 65])
  set(gcf,'color','w')
end 

%%
%First lets threshold the anisotropy values
Total_AnisotropyM(Total_AnisotropyM<0.1)=0;
A=Total_AnisotropyM;
 A([1:6],[1:32])=0;
 A([27:32],[1:32])=0;
 A([1:32],[1:6])=0;
 A([1:32],[27:32])=0;
%L is the length 
%Angle is theta
Total_AngleM(Total_AngleM<0)= NaN;
for i=1:32
    for j=1:32
        L=A(i,j);
        Theta=Total_AngleM(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','R','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 33])
  xlim([0 33])
  set(gcf,'color','w')
end 

%%
%First lets threshold the anisotropy values
Total_AnisotropyM(Total_AnisotropyM<0.1)=0;
A=Total_AnisotropyM;
A([1:4],[1:32])=0;
A([29:32],[1:32])=0;
A([1:32],[1:4])=0;
A([1:32],[29:32])=0;
%L is the length 
%Angle is theta
%Total_AngleM(Total_AngleM<0)= NaN;
for i=1:32
    for j=1:32
        L=2*A(i,j);
        Theta=Total_AngleM(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','R','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 33])
  xlim([0 33])
  set(gcf,'color','w')
end 


%%
%First lets threshold the anisotropy values
Total_AnisotropyO(Total_AnisotropyO<0.25)=0;
A=Total_AnisotropyO;
A([1:2],[1:32])=0;
A([32:32],[1:32])=0;
A([1:32],[1:2])=0;
A([1:32],[31:32])=0;
%L is the length 
%Angle is theta
%Total_AngleM(Total_AngleM<0)= NaN;
for i=1:32
    for j=1:32
        L=A(i,j);
        Theta=Total_AngleO(i,j);
        x=i;
        y=j;
        x2=(x+6*(L*cos(Theta)));
        y2=(y+6*(L*sin(Theta)));
        
plot([x x2],[y y2],'Color','R','Linewidth',2)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 33])
  xlim([0 33])
  set(gcf,'color','w')
end 
%%
%First lets threshold the anisotropy values
Total_AnisotropyM(Total_AnisotropyM<0.1)=0;
A=Total_AnisotropyM;
A(A==NaN)=0;
A([1:4],[1:64])=0;
A([61:64],[1:64])=0;
A([1:64],[1:4])=0;
A([1:64],[61:64])=0;
%L is the length 
%Angle is theta

Total_AngleM(Total_AngleM==0)= NaN;
for i=1:64
    for j=1:64
        L=2*A(i,j);
        Theta=Total_AngleM(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','R','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 65])
  xlim([0 65])
  set(gcf,'color','w')
end 

%%
%%
%First lets threshold the anisotropy values
Total_AnisotropyM(Total_AnisotropyM<0.1)=0;
A=Total_AnisotropyM;
A(A==NaN)=0;
A([1:2],[1:64])=0;
A([63:64],[1:64])=0;
A([1:64],[1:2])=0;
A([1:64],[63:64])=0;
%L is the length 
%Angle is theta

Total_AngleM(Total_AngleM==0)= NaN;
for i=1:64
    for j=1:64
        L=2*A(i,j);
        Theta=Total_AngleM(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','R','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 65])
  xlim([0 65])
  set(gcf,'color','w')
end 

%%
%First lets threshold the anisotropy values
Total_AnisotropyO(Total_AnisotropyO<0.1)=0;
A=Total_AnisotropyO;
A([1:10],[1:64])=0;
A([55:64],[1:64])=0;
A([1:64],[1:10])=0;
A([1:64],[55:64])=0;
%L is the length 
%Angle is theta
%Total_AngleM(Total_AngleM<0)= NaN;
for i=1:64
    for j=1:64
        L=2*A(i,j);
        Theta=Total_AngleO(i,j);
        x=i;
        y=j;
        x2=x+(L*cos(Theta));
        y2=y+(L*sin(Theta));
        
plot([x x2],[y y2],'Color','B','Linewidth',6)
set(gca,'Color','k');
hold on 
    end 
  ylim([0 65])
  xlim([0 65])
  set(gcf,'color','w')
end 