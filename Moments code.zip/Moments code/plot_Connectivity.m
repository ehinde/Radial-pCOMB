function plot_Connectivity(Anisotropy,Angles,pCF_distance,rgb_m)

%First lets threshold the anisotropy values
Total_Anisotropy = Anisotropy;
Total_Angle = Angles;

Total_Anisotropy(Total_Anisotropy<0.15)=0;
A=Total_Anisotropy;
A(A==NaN)=0;
A([1:pCF_distance],[1:size(Anisotropy,2)])=0;
A([(size(Anisotropy,1)-(pCF_distance-1)):size(Anisotropy,1)],[1:size(Anisotropy,2)])=0;
A([1:size(Anisotropy,2)],[1:pCF_distance])=0;
A([1:size(Anisotropy,2)],[(size(Anisotropy,1)-(pCF_distance-1)):size(Anisotropy,2)])=0;

Total_Angle(Total_Angle<0)= 0;
Total_Angle(Total_Angle==0)= NaN;
for i=1:size(Anisotropy,2)
    for j=1:size(Anisotropy,2)
        L=2.5*A(i,j);
        Theta=Total_Angle(i,j);
        x=i;
        y=j;
        x2=(x+2.5*(L*cos(Theta)));
        y2=(y+2.5*(L*sin(Theta)));


plot([x x2],[y y2],'Color',rgb_m,'Linewidth',1.5)
set(gca,'Color','k');
hold on 
    end 
    dimension = size(Anisotropy,2)+1;
  ylim([1 dimension])
  xlim([1 dimension])
  set(gcf,'color','w')
  
hold on

end 