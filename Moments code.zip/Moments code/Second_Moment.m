function [lAxis,sAxis,Eccentricity,Angle,Anisotropy]=Second_Moment(Image)
% This function will calcualte the second moment of the sprite (i.e the
% long and short axis) and from this derive the eccentricity and anisotropy
% values

%Input: 
%   Image
%Outputs:
%    lAxis: the long axis value for the image 
%    sAxis: the short axis value for the image
%    Eccentricity: the eccentricity value for the image
%    Angle: the angle value for the image
%    Anisotropy:the anisotropy value for the image

cm00=cMoment(Image,0,0);
cm20=cMoment(Image,2,0)/cm00;
cm02=cMoment(Image,0,2)/cm00;
cm11=cMoment(Image,1,1)/cm00;

covMat=[cm20 cm11;cm11 cm02];
covMat(isnan(covMat))=0;
[V,D]=eig(covMat);
[D,Order]=sort(diag(D),'descend');
V=V(:,Order);

lAxis=4*sqrt(D(1));
sAxis=4*sqrt(D(2));
Eccentricity=sqrt(1-D(2)/D(1));
Angle=-atan(2*cm11/(cm20-cm02))/2*(180/pi);
Anisotropy=(lAxis-sAxis)/(lAxis+sAxis);
end