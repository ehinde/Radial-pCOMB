function [Raw_Moment]=rMoment(Image,p,q)

% This function will calculate the raw moments (i.e. the moment of the probability
%distribution of a random variable but NOT about the random variables mean)

%Inputs:
%    Image 
%    p: the pth moment alonG the x-axis
%    q: the qth moment along the y-axis 

%Ouputs:
%   Raw_Moment: raw moment at pth and qth moment of image 

Raw_Moment=sum(sum(((1:size(Image,1))'.^q*(1:size(Image,2)).^p).*Image));

end