function [Central_Moment]=cMoment(Image,p,q)

%This function will calculate the central moment (i.e. is the moment of the probability
%distribution of a random variable about the random variables mean)

%Inputs:
%    Image 
%    p: the pth moment along the x-axis
%    q: the qth moment along the y-axis 

%Ouputs:
%   Central_Moment: central moment at pth and qth moment of image 

zero_Moment=rMoment(Image,0,0);
Centroids=[rMoment(Image,1,0)/zero_Moment,rMoment(Image,0,1)/zero_Moment];
Central_Moment=sum(sum((([1:size(Image,1)]-Centroids(2))'.^q*...
    ([1:size(Image,2)]-Centroids(1)).^p).*Image));
        
end 