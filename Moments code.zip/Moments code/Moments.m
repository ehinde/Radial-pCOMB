function [Total_lAxis,Total_sAxis,Total_Eccentricity,Total_Angle,Total_Anisotropy]=Moments(Frames)
% This function will calculate for each sprite the long axis, short
% axis,eccentricity, angle and anisotropy utilsing the moments appraoch

%  Inputs: 
%    Frames: The cell array containing all local rpCOMB/pCF functions

%  Outputs:
%    Total_lAxis: a matrix filled with the long axis value for each
%    individual local rpCOMB/pCF function

%    Total_sAxis: a matrix filled with the short axis value for each
%    individual local rpCOMB/pCF function 

%    Total_Eccentricity: a  matrix filled with the eccentricity value for each
%    individual local rpCOMB/pCF function 

%    Total_Angle: a matrix filled with the angle value for each
%    individual local rpCOMB/pCF function 

%    Total_Anisotropy:a matrix filled with the anisotropy value for each
%    individual local rpCOMB/pCF function

 pCF=Frames;
 Total_lAxis=zeros(size(pCF,1),size(pCF,2));
 
 Total_sAxis=zeros(size(pCF,1),size(pCF,2));
 Total_Eccentricity=zeros(size(pCF,1),size(pCF,2));
 Total_Angle=zeros(size(pCF,1),size(pCF,2));
 Total_Anisotropy=zeros(size(pCF,1),size(pCF,2));
 

for jj=1:size(pCF,1)
    numericCells = pCF(jj,:);
    for kk=1:size(pCF,2)
    numericCells = pCF(jj,kk);
    numericVector = cell2mat(numericCells);
    Sprite=numericVector(:,:);
    Sprite(Sprite<0)=0;
    Image=Sprite;
    [lAxis,sAxis,Eccentricity,Angle,Anisotropy]=Second_Moment(Image);
   
   Total_lAxis(jj,kk)=lAxis;
   Total_sAxis(jj,kk)=sAxis;
   Total_Eccentricity(jj,kk)=Eccentricity;
   Total_Angle(jj,kk)=Angle;
   Total_Anisotropy(jj,kk)=Anisotropy;
   end 
   Total_lAxis=Total_lAxis;
   Total_sAxis=Total_sAxis;
   Total_Eccentricity=Total_Eccentricity;
   Total_Angle=Total_Angle;
   Total_Anisotropy=Total_Anisotropy;
end 
   Total_lAxis(isnan(Total_lAxis))=0;
   Total_sAxis(isnan(Total_sAxis))=0;
   Total_Eccentricity(isnan(Total_Eccentricity))=0;
   Total_Angle(isnan(Total_Angle))=0;
   Total_Anisotropy(isnan(Total_Anisotropy))=0;

end