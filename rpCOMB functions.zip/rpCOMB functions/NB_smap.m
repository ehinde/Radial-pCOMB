
function [NB_map]=NB_smap(Intensity,Monomer, Dimer, Oligomer,frame_number)

    i = frame_number; 
    I = mat2gray(Intensity(:,:,i));
    imRGB = cat(3,I,I,I);
    % All dimer pixels will be magenta with a rgb [255 0 255] and all
    % oligomer pixels will be yellow with a rgb [255 255 0] 
    [m_row, m_col] = find(Monomer(:,:,i));
    RC_M = cat(2,m_row,m_col);
    
    [d_row, d_col] = find(Dimer(:,:,i));
    RC_D = cat(2,d_row,d_col);
    
    [o_row,o_col] = find(Oligomer(:,:,i));
    RC_O = cat(2,o_row,o_col);
  
    redChannel = I; 
    LinIdx_M = sub2ind(size(I),RC_M(:,1), RC_M(:,2));
    redChannel(LinIdx_M)= 0;
    LinIdx_D = sub2ind(size(I),RC_D(:,1), RC_D(:,2));
    redChannel(LinIdx_D)= 0.4;  
    
    LinIdx_O = sub2ind(size(I),RC_O(:,1), RC_O(:,2));
    redChannel(LinIdx_O)= 1;  
    
    greenChannel = I; 
    greenChannel(LinIdx_M)= 0.5; 
    greenChannel(LinIdx_D)= 1;  
    greenChannel(LinIdx_O)= 0; 
   
    blueChannel = I;
    blueChannel(LinIdx_M)= 0.5;
    blueChannel(LinIdx_D)= 0;  
    blueChannel(LinIdx_O)= 0; 
    
    imRGB = cat(3,redChannel,greenChannel,blueChannel);
    [X,cmap] = rgb2ind(imRGB,65);
    NB_map = imRGB;
    
    figure
    imagesc(NB_map)
    set(gca,'Ytick',[])
    set(gca,'Xtick',[])
    
end 
    
    