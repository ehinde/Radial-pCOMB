function[cof]=LambertFun(deadtime,f)
%This function d is the dead time in nanoseconds and the sampling frequency
%f is in Hertz

d=deadtime/1000000000;

for j=1:20
    n=1000000/f;
    c=0.2*(j-1)*n;
    xa(j)=c*exp(-c*f*d);
    ya(j)=c;
end 

pol=fit(xa',ya','poly5');
cof=coeffvalues(pol);

for j=1:20
    a=xa(1,j);
    test=pileupx(a,cof);
end 


end