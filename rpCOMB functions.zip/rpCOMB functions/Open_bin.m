function [data,FileName,PathName]=Open_bin(frame_size)

[FileName,PathName] = uigetfile('*.bin');
fileID = fopen([PathName FileName]);
data = fread(fileID,'uint16');
fclose(fileID);

if rem(size(data,1),frame_size^2) ~= 0
    data = data(3:size(data,1),:);
end 
length = frame_size;
pixels_frame = length*length;
num= size(data,1);
n_frames= floor(num/pixels_frame);
data=reshape(data,length,length,n_frames);

end 