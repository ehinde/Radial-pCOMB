function [intensity_av]=mav_intensity(data, n, deln)
%   This function will apply mav to average frames to match the size of the
%   brightness movie. 
n=n;
deln=deln;
series= data;
numberofwind = floor((size(series,3)-n)/deln)+1;
shiftwind=n/deln;
intensity_av=single(zeros(size(series,1),size(series,2),numberofwind));
for k=1:numberofwind
    lowbd=uint32(1+(k-1)/shiftwind*n);
    upbd=uint32(n*1+((k-1)*deln));
    toanalyze=series(:,:,lowbd:upbd);
    avewind=nanmean(toanalyze,3);
    intensity_av(:,:,k)=avewind;
end
intensity_av(isnan(intensity_av))=0;

end 