function [rpcomb,rpcomb_ma]=av_rpcomb(rpcomb_array,n_delay,mav)

length = size(rpcomb_array,1);


pCOMB_Reshape=reshape(rpcomb_array,1,length.*length);

pCOMB_Stack=zeros(n_delay,n_delay,length.*length);
for ii=1:1:size(rpcomb_array,1)
    numericCells = pCOMB_Reshape(:,ii);
    numericVector = cell2mat(numericCells);
    pCOMB_Stack(:,:,ii)=numericVector;
end

D=mean(pCOMB_Stack,2);
pCOMB_Stack=zeros(n_delay,n_delay.*n_delay);
for ii=1:1:(n_delay*n_delay)
    A=D(:,:,ii);
   
    pCOMB_Stack(:,ii)=A;
end

pCOMB_Stack(isnan(pCOMB_Stack))=0;

D=mean(pCOMB_Stack,2);

D(isnan(D))=0;
ma=movavg(D,'triangular',mav);

rpcomb = D;
rpcomb_ma = ma;

plot(ma,'k','Linewidth',2.5)
hold on
xlabel('Log time(s)');ylabel('G_B_(_t_,_d_r_)');

end 
