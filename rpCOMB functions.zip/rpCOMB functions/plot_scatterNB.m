function plot_scatterNB(NB_Ivals,NB_Bvals)

figure
xlabel('Intensity');ylabel('Brightness');
hold on 
colormap 'jet' 
grid on
fig = dscatter(NB_Ivals,NB_Bvals)
hold on
dscatter(NB_Ivals,NB_Bvals,'smoothing', 20)
hl=linkdata('on');
brush on
linkdata on
set(gcf,'color','w');
pause(.1)
end 