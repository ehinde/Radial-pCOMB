function [output,sdata] = detrend_ra(xa,binsize,method)

% This procedure detrends an array of single data and returns the filtered
% data and smoothed data in sdata 

% Inputs

% n : is the number of points in the vector to detrend
% m : are the number of segments the array is divided for detrending 
% xa : array of single data 
% method : algorithm used to calculate detrend (1-5 options)

    % method = 1 (subtract average of each segment) 
    % method = 2 (moving average gaussian)- make this the default 
    % method = 3 (moving average) 
    % method = 4 (exponential smoothing)
    % method = 5 (exponential smoothing with equalization)

% Outputs

% sdata : is only used for smoothing 

n = size(xa,3);
m = binsize;    % binsize for moving average 
data = xa; 

if m<=2 
    warning('binsize is too small');
end 

ra = n/m;   % number of section to be divided 

if method == 5 
   
% ==== exponential smoothing with equalization ====

auxd = 0; 
mm = m/2; 
a = 1/mm;   % this is the smoothing factor/ coefficient 

if a < 0.00001
    a = 0.00001; % assume a maximum smoothing  

for j = 1 : (n-1)
    ya(j)=data(j);
    auxd = auxd+data(j); 
end 

auxd = auxd/n; 
smoothvector_recursive(ya, n, a); 

for j = 1: (n-mm-1)
    %%%             deficit = sqrt((abs((auxd/ya(j+mm)));
    data(j)= trunc(deficit * (data(j+mm)-ya(j+mm))+auxd);
    sdata(j)= ya(j); 
end 
end     % end of method = 5     

end 

if method == 4
    
% ==== exponential smoothing ====

%    Here we will utilise a simple exponential smoothing algorithm to
%    detrend the temporal series 

auxd = 0; 
mm = m/2; 
a = 1/ mm;  % smoothing factor/coefficient 

if a < 0.00001 
    a = 0.00001;    % assume maximum thresholding 
end 
    for j = 1 : n
        ya(j) = data(j); 
        auxd = auxd + data(j); 
    end
    
    auxd = auxd/n;
    
    D = [1 -1 -1];
    N = 1; 
    y = filter(N,D,zeros(1,n),[0 1]);
    
    % apply a recursive exponential smoothing filter here 
    % apply a recursive exponential smoothing filter 
    % y(i) = a.*x(i)+(1-a)*y(i-1);
   
    
    %smoothvector_rec = @(x,a) filter([a 0]),[1,-(1-a)],x,0));
    
    smoothvector_recursive(ya,n,a); 
    
    for j = 0 : (n-mm-1)
        data(j) = trunc(data(j+m2- ya(j+m2)+auxd));
        sdata(j) = ya(j);
    end 
end     % end of method =4 


if method == 3
   
% ==== moving average ====

mm = m/2; 
%    intialize matrices to be filled 

ya = zeros(1,1,(n-m));    % this is for the moving average 
for i = 1 : (n-m) 
     sec = data(:,:,i:(i+m-1));
            mav = mean(sec(:));
            ya(:,:,i) = mav;
end 
 auxd = mean(data,3); 
 auxd = auxd.*(ones(1,1,(n-m))); % this is the average of the enitre set 
 
 datax = data(:,:,(m/2): ((n-(mm))-1));
 datas = data (:,:,1:((mm)-1));
 datax = datax - ya + auxd; 
 output = cat(3,datas,fix(datax));
 output(output<1)=0;
 
end     % end of method = 3 
        

if method == 2
   
% ==== moving average gaussian ====

mm = m/2; 
%    intialize matrices to be filled 

ya = zeros(1,1,(n-m));    % this is for the moving average 
for i = 1 : (n-m) 
     sec = data(:,:,i:(i+m-1));
            mav = mean(sec(:));
            ya(:,:,i) = mav;
end 
 auxd = mean(data,3); 
 auxd = auxd.*(ones(1,1,(n-m))); % this is the average of the enitre set 
 
 datax = data(:,:,(m/2): ((n-(m/2))-1));
 datas = data (:,:,1:((m/2)-1));
 datax = datax - ya + auxd; 
 output = cat(3,datas,fix(datax));
 output(output<1)=0;
    
    % filter time series with gaussian smoothing
    
    w = gausswin(2); 
    sdata = filter(w, 1, output); 
 
    
end     % end of method = 2 
   

% General code to initialise method = 0, 1, 2, 6

ra = (n-(m));

  % initialising empty array here 
  max_sec = zeros(1,1,ra);
  av_sec = zeros(1,1,ra);
 
 for i = 1 : ra
   sec = data(:,:,i:(i+m-1));
            av = mean(sec(:)); 
            sec = max(sec(:)); 
            max_sec(:,:,i) = sec;
            av_sec(:,:,i) = av;
 end 

if method == 1 
    
% ==== subtract average of each segment ====

datax = data(:,:,(m/2): ((n-(m/2))-1));
datas = data (:,:,1:((m/2)-1));
datax = datax - av_sec + max_sec; 
output = cat(3,datas,fix(datax));

end     % end of method = 1 
sdata= output; 
    
end 


