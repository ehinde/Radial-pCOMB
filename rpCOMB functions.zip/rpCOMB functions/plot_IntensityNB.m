function [NB_Bvals,NB_Ivals,y,x]=plot_IntensityNB(data_B,data_I)

dataB = data_B; 
data= data_I;
Brightness=dataB(:,:,1);
Brightness=Brightness(:);
nn=size(dataB,3);
Intensity= data(:,:,1);%Make brightness and Intenisty equal in size
Intensity(Intensity<=0)=1;
Intents=Intensity(:);

Intensity(Intensity<=0)=1;
Brightness=dataB(:,:,1);
Brightness(Brightness<=0)=1;
Brightness=Brightness(:);
NB_Bvals = Brightness;

[x,y,z]=find(Intensity);
NB_Ivals = z;
scatter(y,x,[],NB_Ivals,'filled')
hold on
 xlim([0 size(data,1)])
 ylim([0 size(data,2)])

camroll(180)
colormap(gray)
linkdata on
set(gcf,'color','w');
pause(.1)
%Must manually adjust the linked data mode on the figure, by adding the z
%variable of the figure. 

end 