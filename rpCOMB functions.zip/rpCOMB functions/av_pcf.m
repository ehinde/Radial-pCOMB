function [av_curve,av_curvema]=av_pcf(array_pcf)
% This function will allow for you to obtain the average correlation curve.

length = size(array_pcf,1);
length_sqr = length.*length;

array_pcf=reshape(array_pcf,1,length_sqr);

pcf_stack=zeros(32,length_sqr);
pcf_stackm=zeros(32,length_sqr);

for i=1:length_sqr
    local_pcf = cell2mat(array_pcf(:,i));
    av_lpcf=mean(local_pcf,2);
    av_lpcfm = movavg(av_lpcf,'triangular',8);

    if max(av_lpcf) < 0.00001
        av_lpcf(:,:) = NaN;
        pcf_stack(:,i)=av_lpcf;
        
    else 
        pcf_stack(:,i)=av_lpcf;

    end 

    if max(av_lpcfm) < 0.00001         
        av_lpcfm(:,:) = NaN;
        pcf_stackm(:,i)=av_lpcfm;
        
    else 
        pcf_stackm(:,i)=av_lpcfm;
   
    end

end 

av_curve=mean(pcf_stack,2,'omitnan');

av_curvema=mean(pcf_stackm,2,'omitnan');


end 