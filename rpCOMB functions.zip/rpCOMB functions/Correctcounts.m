function [Corrected]=Correctcounts(File,deadtime,f)

[cof]=LambertFun(deadtime,f);
Points=File(:);
Num_Points=size(Points,1);

for i=1:Num_Points
D=Points(i,1); 
Correct_counts(:,i)=(pileupx(D,cof));
end
Length=size(File,3);
Side = size(File,1);
Corrected=reshape(Correct_counts,Side,Side,Length);
end 