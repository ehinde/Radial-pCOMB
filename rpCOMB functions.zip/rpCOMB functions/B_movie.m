function[Bmovie]=B_movie(Frames,N,delN) 
%  This function will generate a bmovie with the specified deln and n

%   Inputs:
%       Frames: intensity image stack
%       N: number of frames averaged for brightness calculations 
%       delN: moving window used for calculations (i.e. how much overlap
%       between frames?)

%   Outputs: 
%       Bmovie: Brightness image time series 
n=N;
deln=delN;  %moving average
dataout=Frames;
series=dataout;
numberofwind = floor((size(series,3)-n)/deln)+1;
shiftwind=n/deln;
B=single(zeros(size(series,1),size(series,2),numberofwind));

for k=1:numberofwind
  lowbd=uint32(1+(k-1)/shiftwind*n);
  upbd=uint32(n*1+((k-1)*deln));
  toanalyze=(series(:,:,lowbd:upbd));
  toanalyze=floor(toanalyze);
  avewind= mean((toanalyze),3, 'omitnan');
  varwind=var((toanalyze),[],3,'omitnan');
  B_single= varwind./avewind;
  B(:,:,k)=B_single;  
end
B(isnan(B))=0;
Bmovie=B;

end 