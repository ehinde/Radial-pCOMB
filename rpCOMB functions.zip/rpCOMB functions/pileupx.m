function [Result]=pileupx(x,cof)

x1=x;
x2=x.*x1;
x3=x.*x2;
x4=x.*x3;
x5=x.*x4;

Result=(cof(1,6)+cof(1,5).*x1+cof(1,4).*x^2+cof(1,3).*x^3+cof(1,2).*x4+cof(1,1).*x5);

end 