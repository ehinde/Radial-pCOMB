function [ret, angles, rbins] = pcomb2d(frames, radius, binsize, points)

% pcomb2d: Toan Nguyen, August 2018
% Calculate 2D pCF
% Input
%   frames: 3D stack (x, y, t) matrix
%   radius: radial distance (default = 4)
%   binsize: moving average binsize. binsize=0 (default): no moving average
%   points (optional): 2D array [(x,y),(x,y)...]. If points are given
%   we calculate 2D pCF for the points only. Othewise, calculate for the
%   entire image
% Output
%   ret: array of cells ([width, height] if no point is given; otherwise
%   [numpoints, 1]). Each cell contain 32x32 pCF result. The first index is
%   angle, the second is log scale
%   angles: 32 angle values
%   rbins: 32 log scale values
% Examples
%   result = pcomb2d(frames)
%   [result, angles, rbins] = pcomb2d(frames, 4, 100, [10 20])

if nargin < 1
    error('not enough arguments');
    
elseif nargin == 1
    radius = 4;
    binsize = 10;
    points = [];
    
elseif nargin == 2
    binsize = 10;
    points = [];
    
elseif nargin == 3
    points = [];
end

% moving averaging
oriFrames = frames;
if(binsize > 0)
    if(size(frames,3) / binsize < 10)
        warning('binsize is too big');
    end
    m = movmean(frames,binsize,3);
    frames = frames - m;
end

% constants
DELTA = pi / 16;
NUM_ANGLES = int16(2*pi / DELTA);
%%%%% NUM_LOGSCALE = 32;  %%%%% JUST CHANGE THIS LINE IF WANT MORE LAG TIMES
NUM_LOGSCALE = 32;
[width, height, depth] = size(frames);

% create lookup table for points at a radial distance
angles = zeros(NUM_ANGLES, 1);
offset = zeros(NUM_ANGLES, 2);
for ii = 1:NUM_ANGLES
    angle = double(ii-1)*DELTA;
    angles(ii) = angle;
    offset_col = radius * cos(angle);
    offset_row = radius * sin(angle);
    offset(ii, :) = [offset_col offset_row];
end


% init pair corrlation parameters
firstRow = 1;
lastRow = depth;
N = lastRow - firstRow + 1;
nu = floor(log(N) / log(2));
ntimes = 2^nu; % truncat size of time axis to next lower power of two
numLags = depth - 1;
% init parameters for post processing
dx = exp(log(ntimes)/NUM_LOGSCALE);
rbins = zeros(1, NUM_LOGSCALE);
for tt = 1:NUM_LOGSCALE
    rbins(tt) = power(dx, tt); 
    if(rbins(tt) > ntimes)
        rbins(tt) = ntimes;
    end
end

% main
if isempty(points)
    ret = cell(width, height);
    for col = 1:width
        fprintf('processing col: %d\n', col);
        for row = 1:height
            ret{col, row} = pcomb2d_point([col row]);
        end
    end
else
    ret = cell(size(points, 1), 1);
    for ii = 1 : size(points, 1)
        ret{ii} = pcomb2d_point(points(ii, :));
    end
end

% end main func


    % ==== children functions ====
    function ret_point = pcomb2d_point(point)
        ret_point = zeros(NUM_LOGSCALE, NUM_ANGLES);
        
        c = point(1);
        r = point(2);
        y1 = frames(r, c, :);
        y1_ori = oriFrames(r, c, :);
        for a = 1:NUM_ANGLES
            cc = round(c + offset(a, 1));
            rr = round(r + offset(a, 2));
            if(cc < 1 || cc > width || rr < 1 || rr > height)
                continue;
            end
            y2 = frames(rr, cc, :);
            y2_ori = oriFrames(rr, cc, :);
            xcf = cal_corr(y1, y2, y1_ori, y2_ori, numLags);
            % averaging
            bins = floor(rbins);
            ubins = unique(bins);
            avgResult = zeros(length(ubins), 1);
            avgResult(1, :) = xcf(2);
            for ll=2:length(ubins)
                avgResult(ll) = mean(xcf(ubins(ll-1)+1:ubins(ll))); 
            end
            % interpolation
            finalxcf = interp1(ubins, avgResult, rbins);
            finalxcf(NUM_LOGSCALE) = finalxcf(NUM_LOGSCALE-1);
            ret_point(:, a) = finalxcf(1:NUM_LOGSCALE);
        end
    end
    % ==== end children functions ====


end
    



