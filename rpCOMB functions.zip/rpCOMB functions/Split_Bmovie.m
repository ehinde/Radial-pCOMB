function [Monomer,Dimer,Oligomer]=Split_Bmovie(Bmovie,Min_1,Max_1,Min_2,Max_2,Min_3,Max_3)
%This function will split the brightness movie into three separate matrices
%that will set to zero anything else that is not within the calibrated
%brightness ranges of each oligomeric state.

%Corrective step incorporated to clean zero thresholding step, brightness
%fluctuations with up to 50% zero values will be corrected so that the whole
%fluctuation is made to zero. This is to prevent artefactual correlation
%results with the cal_corr algorithm. 

%INPUTS:

%  Bmovie: the brightness movie 3D Matrix
%  Min_1: the minimum brightness range for monomer
%  Max_1: the maximum brightness range for monomer
%  Min_2: the minimum brightness range for the dimer
%  Max_2: the maximum brightness range for the dimer
%  Min_3: the minimum brightness range for the oligomer

%OUTPUTS: 

%  Monomer: 3D matrix with monomer brightness ranges and rest set to zero
%  Dimer: 3D Matrix  with dimer brightness ranges and rest set to zero
%  Oligomer: 3D Matrix with oligomer brightness ranges and rest set to zero

Bmovie(isnan(Bmovie))=0;
Frames_Monomer=Bmovie;

Frames_Monomer(Frames_Monomer<Min_1)=0;
Frames_Monomer(Frames_Monomer>Max_1)=0;
Monomer=Frames_Monomer;
  
Frames_Dimer=Bmovie; 

Frames_Dimer(Frames_Dimer<Min_2)=0;
Frames_Dimer(Frames_Dimer>Max_2)=0;
Dimer=Frames_Dimer;

Frames_Oligomer=Bmovie;

Frames_Oligomer(Frames_Oligomer<Min_3)=0;
Frames_Oligomer(Frames_Dimer>Max_3)=0;
Oligomer=Frames_Oligomer;



end 