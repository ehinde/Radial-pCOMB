function [datad, datasm]=detrend_image(frames,binsize,method)
% This function will detrend intensity time series image acquisition prior
% to N&B calculations 

%   Inputs 
%   frames: intensity image stack to be detrended 
%   binsize: moving average for detrend algorithm (default binsize = 10) 
%   method: algorithm utilized for detrending ( method= 1

%           method = 1 (subtract average of each segment) 
%           method = 2 (moving average gaussian) 
%           method = 3 (moving average) 
%           method = 4 (exponential smoothing)
%           method = 5 (exponential smoothing with equalization) 

%   Outputs 
%   datad: detrended intensity image stack without smoothing 
%   datasm: detrended intensity image stack with smoothing 

if method == 1 
     fprintf ('Average subtraction of each segment')
end 

if method == 2
     fprintf ('Moving average gaussian')
end 

if method == 3 
     fprintf ('Moving average')
end 

if method == 4 
    fprintf ('Exponential smoothing')
end 

if method == 5 
    fprintf ('Exponential smoothing with equalization')
end 

if nargin < 2
    error(message('detrend_image: Not enought input argument'));
end

[width, height, depth]= size(frames);   % calculate dimensions of frames

n = depth;  % number of points in the time series 
m = binsize; 
mm= m/2; 

if n <= 0 
   error(message('Last frame to process must be larger than the first frame'));
end 

 datad = zeros(width, height, (n-mm-1)); 
 datasm = zeros (width, height, (n-mm-1));
 
 for i = 1 : width 
     
    for  j = 1 : height 
        
     xa = frames(i,j,:); 
     [output,sdata] = detrend_ra(xa,binsize,method);
     datad(i,j,:) = output; 
     datasm(i,j,:) = sdata; 
     
    end 
    
     datad = datad; 
     datasm = datasm; 
 end 

    end  
